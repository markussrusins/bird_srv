# BonziWORLD-Server
Reprogrammed BonziWORLD server with a couple new security features. Works basically like vanilla bonziworld but without all the vulnerabilities. No building required! No built-in banning or kicking though, that's for pussies.

# Dependencies
Node JS, Socket.io and That's it!

# Setup
Run the command "npm install socket.io" in the same folder as index.js. Then run "node index.js". Finally go to http://localhost. If the port is taken, change the port in the config.json file and go to http://localhost:WHATEVERTHEPORTNUMBERIS
